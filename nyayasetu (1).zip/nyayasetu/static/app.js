const $ = s => document.querySelector(s);
const CATS = [["student","🎓","Student"],["woman","👩‍💼","Woman Entrepreneur / Homemaker"],["senior","👵","Senior Citizen"],["farmer","🌾","Farmer"],["daily_wage","🛠️","Daily Wage Worker"]];
const INC = [["u2","Under ₹2 Lakhs"],["2-5","₹2–5 Lakhs"],["5-8","₹5–8 Lakhs"],["8+","Above ₹8 Lakhs"]];
const STAT = [["studying","📚","Studying"],["working","💼","Working"],["neither","🏠","Neither"]];
const LEVEL = [["school","School (Classes 9–12)"],["college","College / University"]];
const CASTE = [["SC","SC (Scheduled Caste)"],["ST","ST (Scheduled Tribe)"],["OBC","OBC (Backward Classes)"],["Minority","Minority community"],["General","General / Other"]];
const STATES = ["Andhra Pradesh","Assam","Bihar","Chhattisgarh","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Odisha","Punjab","Rajasthan","Tamil Nadu","Telangana","Uttar Pradesh","Uttarakhand","West Bengal","Other"];
let ans = {}, idx = 0, DOCS = {}, SCHEMES = [], HAVE = new Set();

// Remembered on this device only (documents the person already has)
try { HAVE = new Set(JSON.parse(localStorage.getItem("ns_have") || "[]")); } catch (e) {}
const toggle = (k, on) => { on ? HAVE.add(k) : HAVE.delete(k); try { localStorage.setItem("ns_have", JSON.stringify([...HAVE])); } catch (e) {} };
const isReady = s => s.docs.every(k => HAVE.has(k));

try { if (localStorage.getItem("ns_big") === "1") document.documentElement.classList.add("big"); } catch (e) {}
$("#textsize").onclick = () => {
  const on = document.documentElement.classList.toggle("big");
  try { localStorage.setItem("ns_big", on ? "1" : "0"); } catch (e) {}
};

function steps() {
  const s = [
    {k:"category", q:"What is your primary category?", o:CATS},
    {k:"income", q:"What is your annual household income?", o:INC},
    {k:"state", q:"Which state do you live in?", select:true},
    {k:"status", q:"Are you currently studying or working?", o:STAT}];
  if (ans.status === "studying") s.push({k:"level", q:"Which level are you studying at?", o:LEVEL});
  if (ans.category === "student" && ans.state === "Karnataka") s.push({k:"caste", q:"Which social category does your family belong to?", o:CASTE});
  return s;
}
function show(id) { document.querySelectorAll(".view").forEach(v => v.hidden = v.id !== id); window.scrollTo(0,0); }

function render() {
  const S = steps(), s = S[idx], box = $("#opts");
  $("#bar").style.width = (idx / S.length * 100) + "%";
  $("#stepno").textContent = `Question ${idx+1} of ${S.length}`;
  $("#q").textContent = s.q;
  $("#next").hidden = !s.select;
  box.innerHTML = "";
  if (s.select) {
    const sel = document.createElement("select");
    sel.setAttribute("aria-label", "State");
    sel.innerHTML = `<option value="">Choose your state</option>` + STATES.map(x => `<option ${ans.state===x?"selected":""}>${x}</option>`).join("");
    sel.onchange = () => ans.state = sel.value;
    box.appendChild(sel);
    return;
  }
  s.o.forEach(a => {
    const [v, e, l] = a.length === 3 ? a : [a[0], "", a[1]];
    const b = document.createElement("button");
    b.className = "opt" + (ans[s.k] === v ? " sel" : "");
    b.innerHTML = (e ? `<span>${e}</span>` : "") + l;
    b.onclick = () => {
      ans[s.k] = v;
      if (s.k === "status" && v !== "studying") delete ans.level;
      advance();
    };
    box.appendChild(b);
  });
}
function advance() {
  if (steps()[idx].select && !ans.state) { alert("Please choose your state."); return; }
  idx++;
  idx >= steps().length ? submit() : render();
}
async function submit() {
  if (!(ans.category === "student" && ans.state === "Karnataka")) delete ans.caste;
  const r = await fetch("/api/match", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(ans)});
  const d = await r.json();
  DOCS = d.docs; SCHEMES = d.schemes;
  renderResults();
  show("results");
}

function renderResults() {
  const n = SCHEMES.length;
  $("#rtitle").textContent = n ? `We found ${n} scheme${n > 1 ? "s" : ""} for you` : "No exact matches yet";
  $(".actions").hidden = !n;

  // Cross-scheme paperwork: which document unlocks the most schemes?
  const need = {};
  SCHEMES.forEach(s => s.docs.forEach(k => (need[k] = need[k] || []).push(s.name)));
  const keys = Object.keys(need).sort((a, b) => need[b].length - need[a].length);
  $("#start-here").hidden = !keys.length;
  const ul = $("#docs-needed"); ul.innerHTML = "";
  keys.forEach(k => {
    const c = need[k].length, has = HAVE.has(k), li = document.createElement("li");
    li.className = has ? "done" : "";
    li.innerHTML = `<label><input type="checkbox" ${has ? "checked" : ""}> <span>${DOCS[k][0]}</span> <em>unlocks ${c} scheme${c > 1 ? "s" : ""}</em></label>` + (has ? "" : `<p class="how">How to get it: ${DOCS[k][1]}</p>`);
    li.querySelector("input").onchange = e => { toggle(k, e.target.checked); renderResults(); };
    ul.appendChild(li);
  });

  const box = $("#cards");
  box.innerHTML = n ? "" : "<p>Try changing your income bracket or category, or visit your nearest Common Service Centre for help.</p>";
  [...SCHEMES].sort((a, b) => isReady(b) - isReady(a)).forEach(s => {
    const have = s.docs.filter(k => HAVE.has(k)).length, ok = isReady(s);
    const c = document.createElement("div");
    c.className = "card";
    c.innerHTML = `<span class="badge">${s.match}% Match</span><h3>${s.name}</h3><p class="benefit">${s.benefit}</p><p class="why">Why you qualify: ${s.why}</p><p class="ready ${ok ? "ok" : ""}">${ok ? "✔ Ready to apply" : `${have} of ${s.docs.length} documents ready`}</p>`;
    const b = document.createElement("button");
    b.className = "cta small"; b.textContent = "Check my documents";
    b.onclick = () => openModal(s);
    c.appendChild(b); box.appendChild(c);
  });
}

function openModal(s) {
  $("#mtitle").textContent = s.name;
  $("#mbenefit").textContent = s.benefit + (s.note ? ` (${s.note})` : "");
  $("#mapply").textContent = "Where to apply: " + s.apply;
  const ul = $("#checklist"); ul.innerHTML = "";
  const update = () => {
    const boxes = ul.querySelectorAll("input"); let n = 0;
    boxes.forEach(b => { if (b.checked) n++; b.closest("li").querySelector(".how").hidden = b.checked; });
    $("#mstatus").textContent = n === boxes.length ? "You have everything. You are ready to apply." : `${n} of ${boxes.length} documents ready`;
  };
  s.docs.forEach(k => {
    const [name, how] = DOCS[k], li = document.createElement("li");
    li.innerHTML = `<label><input type="checkbox" ${HAVE.has(k) ? "checked" : ""}> ${name}</label><p class="how">How to get it: ${how}</p>`;
    li.querySelector("input").onchange = e => { toggle(k, e.target.checked); update(); renderResults(); };
    ul.appendChild(li);
  });
  update();
  $("#modal").hidden = false;
}

function missing(s) { return s.docs.filter(k => !HAVE.has(k)).map(k => DOCS[k][0]); }
$("#print").onclick = () => {
  const todo = [...new Set(SCHEMES.flatMap(s => s.docs).filter(k => !HAVE.has(k)))];
  $("#plan").innerHTML = `<h1>My NyayaSetu Action Plan</h1><p>Prepared on ${new Date().toLocaleDateString("en-IN")} at NyayaSetu.so</p>
    <h2>Schemes I may qualify for</h2><ol>${SCHEMES.map(s => `<li><b>${s.name}</b>: ${s.benefit}.<br>Apply at: ${s.apply}.<br>Still missing: ${missing(s).join(", ") || "nothing, ready to apply"}.</li>`).join("")}</ol>
    <h2>Papers to collect first</h2><ol>${todo.map(k => `<li><b>${DOCS[k][0]}</b>: ${DOCS[k][1]}</li>`).join("") || "<li>You have all the papers.</li>"}</ol>
    <p>Scheme rules change. Please confirm details on the official portal before applying.</p>`;
  window.print();
};
$("#wa").onclick = () => {
  const todo = [...new Set(SCHEMES.flatMap(s => s.docs).filter(k => !HAVE.has(k)))].map(k => DOCS[k][0]);
  const t = `I checked NyayaSetu.so and may qualify for ${SCHEMES.length} government schemes:\n` + SCHEMES.slice(0, 5).map(s => `• ${s.name} (${s.benefit})`).join("\n") + (todo.length ? `\n\nPapers to collect first: ${todo.slice(0, 4).join(", ")}` : "\n\nI already have all the papers.");
  window.open("https://wa.me/?text=" + encodeURIComponent(t), "_blank");
};

$("#start").onclick = () => { ans = {}; idx = 0; render(); show("wizard"); };
$("#next").onclick = advance;
$("#back").onclick = () => idx > 0 ? (idx--, render()) : show("home");
$("#redo").onclick = () => show("home");
$("#mclose").onclick = () => $("#modal").hidden = true;
$("#modal").onclick = e => { if (e.target.id === "modal") $("#modal").hidden = true; };
document.addEventListener("keydown", e => { if (e.key === "Escape") $("#modal").hidden = true; });
